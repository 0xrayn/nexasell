"use client";
import { useState, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import {
  CheckCircle2, Clock, Copy, ArrowLeft, Banknote,
  Wallet, Smartphone, CreditCard, ChevronDown, ChevronUp,
  RefreshCw, Shield, Zap, ExternalLink,
} from "lucide-react";
import Link from "next/link";
import Navbar from "@/components/ui/Navbar";
import Footer from "@/components/ui/Footer";
import { formatRupiah } from "@/lib/utils";
import { useTheme } from "@/lib/ThemeContext";

/* ─── Types ─── */
type PayStatus = "pending" | "checking" | "success" | "failed" | "expired";
type MethodKey = "bank_transfer" | "ewallet" | "qris" | "credit_card" | "cod";

interface PayMethod {
  key: MethodKey;
  label: string;
  icon: React.ElementType;
  color: string;
  vaNumber?: string;
  bank?: string;
  ewalletNumber?: string;
  qrUrl?: string;
  instructions: string[];
}

/* ─── Payment methods ─── */
const METHODS: PayMethod[] = [
  {
    key: "bank_transfer",
    label: "Bank Transfer (BCA)",
    icon: Banknote,
    color: "#0060AF",
    bank: "BCA",
    vaNumber: "8277-0825-1234-5678",
    instructions: [
      "Buka aplikasi BCA Mobile atau ATM BCA",
      "Pilih Transfer → BCA Virtual Account",
      "Masukkan nomor VA: 8277-0825-1234-5678",
      "Konfirmasi nominal, lalu selesaikan pembayaran",
      "Pembayaran terverifikasi otomatis dalam 1–5 menit",
    ],
  },
  {
    key: "ewallet",
    label: "GoPay / OVO / DANA",
    icon: Wallet,
    color: "#00AED6",
    ewalletNumber: "0800-1234-567",
    instructions: [
      "Buka aplikasi GoPay, OVO, atau DANA",
      "Pilih Transfer / Kirim Uang",
      "Masukkan nomor: 0800-1234-567",
      "Konfirmasi nominal dan selesaikan pembayaran",
    ],
  },
  {
    key: "qris",
    label: "QRIS (Semua E-Wallet)",
    icon: Smartphone,
    color: "#E02020",
    qrUrl: "https://api.qrserver.com/v1/create-qr-code/?data=NEXASELL-PAY-ORD2024-0042&size=200x200",
    instructions: [
      "Buka aplikasi e-wallet yang mendukung QRIS",
      "Pilih fitur Scan / Pay",
      "Scan QR code di atas",
      "Konfirmasi pembayaran",
    ],
  },
  {
    key: "credit_card",
    label: "Kartu Kredit / Debit",
    icon: CreditCard,
    color: "#6366F1",
    instructions: [
      "Klik tombol 'Bayar dengan Kartu' di bawah",
      "Anda diarahkan ke halaman aman Midtrans",
      "Masukkan data kartu kredit/debit Anda",
      "OTP dikirim ke nomor HP terdaftar",
      "Pembayaran dikonfirmasi otomatis",
    ],
  },
  {
    key: "cod",
    label: "Bayar di Tempat (COD)",
    icon: Banknote,
    color: "#10B981",
    instructions: [
      "Siapkan uang tunai sesuai nominal pesanan",
      "Kurir menghubungi sebelum tiba",
      "Bayar langsung kepada kurir saat barang diterima",
      "Pastikan Anda menerima struk pembayaran",
    ],
  },
];

/* ─── Mock order ─── */
const MOCK_ORDER = {
  id: "ORD-2024-0042",
  total: 1_250_000,
  items: [{ name: "Smart Watch Series 5", qty: 1, price: 1_250_000 }],
  customerName: "Budi Santoso",
  expiredAt: Date.now() + 24 * 60 * 60 * 1000,
};

/* ─── Countdown ─── */
function useCountdown(targetMs: number) {
  const [left, setLeft] = useState(Math.max(targetMs - Date.now(), 0));
  useEffect(() => {
    const t = setInterval(() => setLeft(Math.max(targetMs - Date.now(), 0)), 1000);
    return () => clearInterval(t);
  }, [targetMs]);
  return {
    h: Math.floor(left / 3_600_000),
    m: Math.floor((left % 3_600_000) / 60_000),
    s: Math.floor((left % 60_000) / 1000),
    expired: left <= 0,
  };
}

/* ─── Copy button ─── */
function CopyButton({ text, dark }: { text: string; dark: boolean }) {
  const [copied, setCopied] = useState(false);
  const handle = () => {
    navigator.clipboard.writeText(text.replace(/[- ]/g, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      onClick={handle}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold flex-shrink-0"
      style={{
        background: copied ? "#10b981" : "rgba(99,102,241,.15)",
        color: copied ? "#fff" : "#6366f1",
        border: `1px solid ${copied ? "#10b981" : "rgba(99,102,241,.3)"}`,
        transition: "all .2s",
      }}
    >
      {copied ? <CheckCircle2 className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
      {copied ? "Disalin!" : "Salin"}
    </button>
  );
}

/* ─── Main inner component (uses useSearchParams) ─── */
function PaymentInner() {
  const { dark } = useTheme();
  const router = useRouter();
  const searchParams = useSearchParams();

  const order = MOCK_ORDER; // In production: fetch by searchParams.get("orderId")

  const [activeKey, setActiveKey] = useState<MethodKey>("bank_transfer");
  const [status, setStatus] = useState<PayStatus>("pending");
  const [showInstructions, setShowInstructions] = useState(true);
  const [simLoading, setSimLoading] = useState(false);

  const method = METHODS.find((m) => m.key === activeKey)!;
  const countdown = useCountdown(order.expiredAt);

  const card: React.CSSProperties = {
    background: dark ? "rgba(255,255,255,.04)" : "#fff",
    border: `1px solid ${dark ? "rgba(255,255,255,.08)" : "rgba(99,102,241,.14)"}`,
    borderRadius: 20,
    boxShadow: dark ? "0 4px 24px rgba(0,0,0,.3)" : "0 4px 24px rgba(99,102,241,.08)",
  };

  const checkPayment = () => {
    setSimLoading(true);
    setStatus("checking");
    setTimeout(() => {
      setSimLoading(false);
      setStatus("success");
    }, 2000);
  };

  /* ── SUCCESS ── */
  if (status === "success") {
    return (
      <div className="flex-1 flex items-center justify-center px-4 py-24">
        <div className="flex flex-col items-center gap-6 text-center max-w-sm w-full">
          <div className="w-24 h-24 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#10b981,#059669)", boxShadow: "0 16px 48px rgba(16,185,129,.35)" }}>
            <CheckCircle2 className="w-12 h-12 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-black mb-2" style={{ color: "var(--text)" }}>Pembayaran Berhasil!</h2>
            <p className="text-sm" style={{ color: "var(--text2)" }}>
              Pesanan <span className="font-bold" style={{ color: "#6366f1" }}>{order.id}</span> sedang diproses.
              Estimasi pengiriman 2–3 hari kerja.
            </p>
          </div>
          <div className="w-full p-4 rounded-2xl" style={card}>
            <div className="flex justify-between text-sm mb-2">
              <span style={{ color: "var(--text2)" }}>Total Dibayar</span>
              <span className="font-black" style={{ color: "#10b981" }}>{formatRupiah(order.total)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span style={{ color: "var(--text2)" }}>Metode</span>
              <span className="font-bold" style={{ color: "var(--text)" }}>{method.label}</span>
            </div>
          </div>
          <Link href="/"
            className="w-full py-3.5 rounded-2xl text-white text-sm font-black text-center"
            style={{ background: "linear-gradient(135deg,#6366f1,#7c3aed)", boxShadow: "0 4px 20px rgba(99,102,241,.4)" }}>
            Kembali ke Toko
          </Link>
        </div>
      </div>
    );
  }

  /* ── EXPIRED ── */
  if (countdown.expired) {
    return (
      <div className="flex-1 flex items-center justify-center px-4 py-24">
        <div className="flex flex-col items-center gap-6 text-center max-w-sm">
          <div className="w-24 h-24 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg,#f59e0b,#d97706)", boxShadow: "0 16px 48px rgba(245,158,11,.35)" }}>
            <Clock className="w-12 h-12 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-black mb-2" style={{ color: "var(--text)" }}>Pembayaran Kedaluwarsa</h2>
            <p className="text-sm" style={{ color: "var(--text2)" }}>Batas waktu pembayaran telah habis. Silakan buat pesanan baru.</p>
          </div>
          <Link href="/customer/cart"
            className="w-full py-3.5 rounded-2xl text-white text-sm font-black text-center"
            style={{ background: "linear-gradient(135deg,#6366f1,#7c3aed)", boxShadow: "0 4px 20px rgba(99,102,241,.4)" }}>
            Kembali ke Keranjang
          </Link>
        </div>
      </div>
    );
  }

  /* ── MAIN ── */
  return (
    <main className="flex-1 max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-10">

      {/* Back */}
      <Link href="/customer/checkout"
        className="inline-flex items-center gap-2 text-sm font-semibold mb-6"
        style={{ color: "var(--text2)" }}>
        <ArrowLeft className="w-4 h-4" /> Kembali ke Checkout
      </Link>

      {/* Title */}
      <div className="mb-6">
        <div className="flex flex-wrap items-center gap-3 mb-1">
          <h1 className="text-xl sm:text-2xl font-black" style={{ color: "var(--text)" }}>
            Selesaikan Pembayaran
          </h1>
          <span className="text-[10px] font-black px-2.5 py-1 rounded-full text-white"
            style={{ background: "linear-gradient(135deg,#003cff,#0066ff)", boxShadow: "0 2px 8px rgba(0,60,255,.3)" }}>
            🔒 Powered by Midtrans
          </span>
        </div>
        <p className="text-sm" style={{ color: "var(--text2)" }}>
          Order <span className="font-bold" style={{ color: "#6366f1" }}>{order.id}</span>
          {" · "}{order.customerName}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-5">

        {/* ── LEFT ── */}
        <div className="flex flex-col gap-4">

          {/* Countdown */}
          <div className="flex items-center justify-between px-4 py-3 rounded-2xl"
            style={{
              background: dark ? "rgba(245,158,11,.08)" : "rgba(255,252,235,.95)",
              border: `1px solid ${dark ? "rgba(245,158,11,.25)" : "rgba(245,158,11,.35)"}`,
            }}>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              <span className="text-xs font-semibold" style={{ color: dark ? "#fde68a" : "#92400e" }}>
                Batas waktu pembayaran
              </span>
            </div>
            <span className="text-sm font-black tabular-nums"
              style={{ color: countdown.h === 0 && countdown.m < 10 ? "#ef4444" : "#d97706" }}>
              {String(countdown.h).padStart(2, "0")}:{String(countdown.m).padStart(2, "0")}:{String(countdown.s).padStart(2, "0")}
            </span>
          </div>

          {/* Method selector */}
          <div style={card} className="p-4">
            <p className="text-xs font-black uppercase tracking-widest mb-3"
              style={{ color: dark ? "rgba(255,255,255,.4)" : "rgba(99,102,241,.7)" }}>
              Pilih Metode Pembayaran
            </p>
            <div className="flex flex-col gap-2">
              {METHODS.map((m) => {
                const Icon = m.icon;
                const active = activeKey === m.key;
                return (
                  <button
                    key={m.key}
                    type="button"
                    onClick={() => setActiveKey(m.key)}
                    className="flex items-center gap-3 px-4 py-3 rounded-2xl text-left w-full"
                    style={{
                      background: active
                        ? dark ? `${m.color}22` : `${m.color}14`
                        : "transparent",
                      border: `1.5px solid ${active
                        ? m.color
                        : dark ? "rgba(255,255,255,.07)" : "rgba(0,0,0,.07)"}`,
                      cursor: "pointer",
                      transition: "border-color .15s, background .15s",
                    }}
                  >
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: `${m.color}20`, border: `1px solid ${m.color}35` }}>
                      <Icon className="w-4 h-4" style={{ color: m.color }} />
                    </div>
                    <span className="text-sm font-bold flex-1 text-left" style={{ color: "var(--text)" }}>
                      {m.label}
                    </span>
                    {/* Radio indicator */}
                    <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                      style={{ borderColor: active ? m.color : dark ? "rgba(255,255,255,.2)" : "rgba(0,0,0,.2)" }}>
                      {active && (
                        <div className="w-2.5 h-2.5 rounded-full"
                          style={{ background: m.color }} />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment detail */}
          <div style={card} className="p-4">
            <p className="text-xs font-black uppercase tracking-widest mb-4"
              style={{ color: dark ? "rgba(255,255,255,.4)" : "rgba(99,102,241,.7)" }}>
              Detail Pembayaran
            </p>

            {/* VA Number */}
            {method.vaNumber && (
              <div className="mb-5">
                <p className="text-xs font-semibold mb-2" style={{ color: "var(--text2)" }}>
                  Virtual Account {method.bank}
                </p>
                <div className="flex items-center gap-3 px-4 py-3.5 rounded-2xl"
                  style={{
                    background: dark ? "rgba(255,255,255,.05)" : "rgba(99,102,241,.05)",
                    border: `1.5px dashed ${dark ? "rgba(255,255,255,.18)" : "rgba(99,102,241,.3)"}`,
                  }}>
                  <span className="flex-1 text-base font-black tracking-widest tabular-nums"
                    style={{ color: "var(--text)", letterSpacing: "0.1em" }}>
                    {method.vaNumber}
                  </span>
                  <CopyButton text={method.vaNumber} dark={dark} />
                </div>
              </div>
            )}

            {/* E-wallet number */}
            {method.ewalletNumber && (
              <div className="mb-5">
                <p className="text-xs font-semibold mb-2" style={{ color: "var(--text2)" }}>
                  Nomor E-Wallet
                </p>
                <div className="flex items-center gap-3 px-4 py-3.5 rounded-2xl"
                  style={{
                    background: dark ? "rgba(255,255,255,.05)" : "rgba(99,102,241,.05)",
                    border: `1.5px dashed ${dark ? "rgba(255,255,255,.18)" : "rgba(99,102,241,.3)"}`,
                  }}>
                  <span className="flex-1 text-base font-black tracking-widest tabular-nums"
                    style={{ color: "var(--text)" }}>
                    {method.ewalletNumber}
                  </span>
                  <CopyButton text={method.ewalletNumber} dark={dark} />
                </div>
              </div>
            )}

            {/* QRIS */}
            {method.qrUrl && (
              <div className="flex flex-col items-center gap-3 mb-5">
                <p className="text-xs font-semibold self-start" style={{ color: "var(--text2)" }}>
                  Scan QR Code ini
                </p>
                <div className="p-3 rounded-2xl bg-white"
                  style={{ boxShadow: "0 4px 24px rgba(0,0,0,.12)" }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={method.qrUrl} alt="QRIS QR Code" className="w-44 h-44" />
                </div>
                <p className="text-[10px] font-semibold text-center" style={{ color: "var(--text3)" }}>
                  QR ini berlaku hingga batas waktu pembayaran
                </p>
              </div>
            )}

            {/* Credit card */}
            {method.key === "credit_card" && (
              <div className="mb-5">
                <button
                  type="button"
                  onClick={() => {
                    // TODO: call POST /api/payment/create → get snap_token → window.snap.pay(token)
                    alert("TODO: panggil POST /api/payment/create untuk dapat snap_token Midtrans,\nlalu window.snap.pay(snapToken)");
                  }}
                  className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl text-white text-sm font-black"
                  style={{
                    background: "linear-gradient(135deg,#6366f1,#7c3aed)",
                    boxShadow: "0 4px 20px rgba(99,102,241,.45)",
                    cursor: "pointer",
                  }}>
                  <ExternalLink className="w-4 h-4" />
                  Bayar dengan Kartu — Lanjut ke Midtrans
                </button>
                <p className="text-[10px] text-center mt-2 font-semibold" style={{ color: "var(--text3)" }}>
                  Anda akan diarahkan ke halaman pembayaran aman Midtrans
                </p>
              </div>
            )}

            {/* COD info */}
            {method.key === "cod" && (
              <div className="mb-5 px-4 py-3 rounded-2xl"
                style={{
                  background: dark ? "rgba(16,185,129,.08)" : "rgba(16,185,129,.07)",
                  border: "1px solid rgba(16,185,129,.25)",
                }}>
                <p className="text-xs font-bold" style={{ color: "#059669" }}>
                  💵 Bayar tunai saat barang tiba. Siapkan uang pas ya!
                </p>
              </div>
            )}

            {/* Instructions */}
            <div>
              <button
                type="button"
                onClick={() => setShowInstructions((p) => !p)}
                className="flex items-center justify-between w-full text-left mb-3"
                style={{ cursor: "pointer" }}>
                <p className="text-xs font-black uppercase tracking-widest"
                  style={{ color: dark ? "rgba(255,255,255,.4)" : "rgba(99,102,241,.7)" }}>
                  Cara Pembayaran
                </p>
                {showInstructions
                  ? <ChevronUp className="w-4 h-4" style={{ color: "var(--text3)" }} />
                  : <ChevronDown className="w-4 h-4" style={{ color: "var(--text3)" }} />
                }
              </button>
              {showInstructions && (
                <ol className="flex flex-col gap-2.5">
                  {method.instructions.map((step, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <span className="w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center text-[10px] font-black text-white mt-0.5"
                        style={{ background: method.color }}>
                        {i + 1}
                      </span>
                      <span className="text-xs leading-relaxed" style={{ color: "var(--text2)" }}>{step}</span>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </div>

          {/* Check payment button */}
          {method.key !== "credit_card" && method.key !== "cod" && (
            <button
              type="button"
              onClick={checkPayment}
              disabled={simLoading}
              className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl text-sm font-black text-white"
              style={{
                background: simLoading ? "rgba(99,102,241,.5)" : "linear-gradient(135deg,#6366f1,#7c3aed)",
                boxShadow: simLoading ? "none" : "0 4px 20px rgba(99,102,241,.45)",
                cursor: simLoading ? "not-allowed" : "pointer",
                transition: "all .2s",
              }}>
              <RefreshCw className={`w-4 h-4 ${simLoading ? "animate-spin" : ""}`} />
              {simLoading ? "Mengecek Pembayaran..." : "Cek Status Pembayaran"}
            </button>
          )}

          {/* COD confirm */}
          {method.key === "cod" && (
            <button
              type="button"
              onClick={() => setStatus("success")}
              className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl text-sm font-black text-white"
              style={{
                background: "linear-gradient(135deg,#10b981,#059669)",
                boxShadow: "0 4px 20px rgba(16,185,129,.35)",
                cursor: "pointer",
              }}>
              <CheckCircle2 className="w-4 h-4" />
              Konfirmasi Pesanan COD
            </button>
          )}
        </div>

        {/* ── RIGHT: Order summary ── */}
        <div className="flex flex-col gap-4">

          {/* Order summary */}
          <div style={card} className="p-4">
            <p className="text-xs font-black uppercase tracking-widest mb-3"
              style={{ color: dark ? "rgba(255,255,255,.4)" : "rgba(99,102,241,.7)" }}>
              Ringkasan Pesanan
            </p>
            <div className="flex flex-col gap-3 mb-4">
              {order.items.map((item, i) => (
                <div key={i} className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold" style={{ color: "var(--text)" }}>{item.name}</p>
                    <p className="text-[11px]" style={{ color: "var(--text3)" }}>× {item.qty}</p>
                  </div>
                  <p className="text-xs font-black tabular-nums flex-shrink-0"
                    style={{ color: "var(--text)" }}>{formatRupiah(item.price * item.qty)}</p>
                </div>
              ))}
            </div>
            <div className="pt-3 flex items-center justify-between"
              style={{ borderTop: `1px solid ${dark ? "rgba(255,255,255,.08)" : "rgba(0,0,0,.06)"}` }}>
              <span className="text-sm font-bold" style={{ color: "var(--text2)" }}>Total</span>
              <span className="text-base font-black" style={{ color: "#6366f1" }}>{formatRupiah(order.total)}</span>
            </div>
          </div>

          {/* Security */}
          <div style={card} className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4 text-emerald-500" />
              <span className="text-xs font-black" style={{ color: "var(--text)" }}>Transaksi Aman</span>
            </div>
            {[
              "Diproses oleh Midtrans (PCI DSS compliant)",
              "Data kartu terenkripsi & tidak disimpan",
              "Pembayaran dijamin terlindungi",
            ].map((t, i) => (
              <div key={i} className="flex items-start gap-2 mb-2 last:mb-0">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                <span className="text-[11px]" style={{ color: "var(--text2)" }}>{t}</span>
              </div>
            ))}
          </div>

          {/* Dev note */}
          <div className="px-4 py-3 rounded-2xl"
            style={{
              background: dark ? "rgba(99,102,241,.08)" : "rgba(99,102,241,.06)",
              border: `1px solid ${dark ? "rgba(99,102,241,.25)" : "rgba(99,102,241,.20)"}`,
            }}>
            <div className="flex items-center gap-2 mb-1.5">
              <Zap className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[10px] font-black uppercase tracking-wider" style={{ color: "#818cf8" }}>
                Dev Note — Midtrans
              </span>
            </div>
            <p className="text-[10px] leading-relaxed" style={{ color: "var(--text3)" }}>
              Frontend siap. Untuk live:{" "}
              <code style={{ color: "#a5b4fc" }}>POST /api/payment/create</code> → dapat{" "}
              <code style={{ color: "#a5b4fc" }}>snap_token</code> →{" "}
              <code style={{ color: "#a5b4fc" }}>window.snap.pay(token)</code>.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}

/* ─── Page export with Suspense (required for useSearchParams) ─── */
export default function PaymentPage() {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--bg)" }}>
      <Navbar />
      <Suspense fallback={
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <RefreshCw className="w-8 h-8 animate-spin" style={{ color: "#6366f1" }} />
            <p className="text-sm font-semibold" style={{ color: "var(--text2)" }}>Memuat halaman pembayaran...</p>
          </div>
        </div>
      }>
        <PaymentInner />
      </Suspense>
      <Footer />
    </div>
  );
}
